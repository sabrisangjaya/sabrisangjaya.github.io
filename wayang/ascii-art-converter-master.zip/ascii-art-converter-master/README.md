# Ascii Art Converter

Support project for tutorial: [Converting an Image into Ascii Art](https://www.jonathan-petitcolas.com/2017/12/28/converting-image-to-ascii-art.html).
